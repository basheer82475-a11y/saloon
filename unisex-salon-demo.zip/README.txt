﻿UNISEX SALON — Website Preview

Extract this ZIP, keep index.html and logo.svg together, then open index.html in a web browser. The preview uses no external libraries.

Please confirm the displayed phone/WhatsApp number and +91 country code, salon address, opening hours, and prices cut off in the supplied price-list photo.
